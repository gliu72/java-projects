
package business;

/**
 *
 * @author George L
 */
public class LetterCodeLogic {
    public static String Encode(String msg){
    // method to encode message string to numbers...
        String result="";
        String m = msg.toUpperCase();
        char c; // single character use '' not ""
        int x; // use char to int based on ASCII coding scheme
        
        for (int i=0; i < m.length(); i++){
            c = m.charAt(i);
            x = c; // turn charcter into number
            
            if (x==32){
                x = 0;
                
            } else {
                x -= 64; // adjust ASCII values of A,B,C to 1,2,3...
                if (x < 1 || x > 26){
                    x = 99;
                }
                
            }
            
            result += String.valueOf(x) + " ";
            
            
        }
        
        
        
        return result; 
    } // End of encode
    
    public static String Decode(String msg){
        String result = ""; 
        // How to extract seperate numbers from message
        // seperated by commas 
        // Use: split method of strings: 
        // string "1,2,3" splits into arrray of strings with [0]=1, [1]=2, etc. 
        String[] nums = msg.split(",");
        
        // in above example, "1,2,3" becomes nums[0]=1, nums[1]=2, nums[2]=3
        // hint: use for loop with length of nums as your range 
        // use x=Integer.parseInt(nums[i])--> to convert string nums[i] to integer 
        // then process is reverse of Encode 
        
        
        return result; 
    }
    
}
