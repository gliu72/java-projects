
package conversions;

import java.util.Scanner;
import static java.lang.Math.*;


/**
 *
 * @author George Liu
 */
public class Conversions {

    static Scanner sc = new Scanner(System.in);
    
    
    
    public static void main(String[] args) {
        boolean usingk = false; 
        int choice; 
        String choicek; 
        
        
        System.out.println("Welcome to George's Conversions Program. ");
        
        System.out.print("On Temp conversions, would you also like to see degrees Kelvin (K) in the results? Enter (Y/N): ");
        choicek = sc.nextLine();
        
        if (choicek.toUpperCase().startsWith("Y")) {
            usingk=true;
        } else {
            usingk=false; 
        }
        
        
        choice=getCType(); 
        
        while (choice != 0){
            switch (choice){
                case 1: 
                    MitoKm();
                    break;
                case 2:
                    OztoGr();
                    break;
                case 3:
                    FtoC(usingk);
                    break;
                case 4: 
                    CtoF(usingk); 
                    break; 
                default: 
                    System.out.println("Error: choice not recognized. ");
                    break;
            
            
            }
        
            choice=getCType(); 
        }
       
        
        
        System.out.println("Thanks for using George's Conversions Program. ");
    } // end of main
    
    
    public static int getCType(){
        int c = -1;
        do {
            try {
                System.out.print("Select conversion type. (1=mi-to-km, 2=oz-to-gr, 3=f-to-c, 4=c-to-f, 0=end):"); 
                c = sc.nextInt();
                if (c < 0 || c > 4){
                    System.out.println("Choice is out of bounds. Enter 0-4 only. ");
                }
            } catch (Exception e){
                System.out.println("Illegal input. Not an integer. ");
                sc.nextLine(); 
                c=-1; 
                    
                
            }
    
        } while (c < 0 || c > 4);
        return c; 
    }
    
    public static double getValue(String convtype){
        boolean badval;
        badval=true; 
        double v=0.00; 
        
        do {
            try {
                System.out.print("Enter your " + convtype + " : "); 
                v = sc.nextDouble();
                badval=false; 
            } catch (Exception e){
                System.out.println("Illegal input. Not a valid number. ");
                sc.nextLine(); 
                 }
            
        } while (badval);
        
        return v; 
    }
    
    public static void MitoKm(){
        double miles=-1; 
        double kilometers; 
        
        while(miles<0){
            miles=getValue("miles");
            if(miles<0){
                System.out.println("Illegal value: Enter a positive value of miles. ");
            }
        }
        kilometers =  1.60934 * miles; 
        
        System.out.println("A length of " + miles + " mile(s) converted to kilometer(s) = " + kilometers + " km. ");
    }
    
    public static void OztoGr(){
        double ounces=-1; 
        double grams; 
        
        while(ounces<0){
            ounces=getValue("ounces");
            if(ounces<0){
                System.out.println("Illegal value: Enter a positive value of ounces. ");
            }
        }
        
        grams=28.35*ounces; 
        
        System.out.println("A mass of " + ounces + " ounce(s) converted to gram(s) = " + grams + " g. ");
    }
    
    public static void FtoC(boolean usingk){
        double Fahrenheit; 
        double Celsius; 
        
        Fahrenheit = getValue("Fahrenheit temperature");
        Celsius = ( (Fahrenheit - 32) * 5/9 ) ; 
        
        System.out.println("A temperature of " + Fahrenheit + " degree(s) Fahrenheit converted to Celsius(s) = " + Celsius + " celsius. ");
        
        if (usingk){
            showDegreesK(Celsius); 
        }
        
    }
    
    public static void CtoF(boolean usingk){
        double Fahrenheit; 
        double Celsius; 
        
        Celsius=getValue("Celsius temperature");
        Fahrenheit=(1.8 * Celsius ) + 32; 
        
        System.out.println("A temperature of " + Celsius + " degree(s) Celsius converted to Fahrenheit(s) = " + Fahrenheit + " Fahrenheit. ");
        
        if (usingk){
            showDegreesK(Celsius); 
        }
        
    }
    
    public static void showDegreesK(double celsius){
        double tk; 
        
        tk= 273.15 + celsius; 
        
        if(tk<0){
        System.out.println("This temperature is below 0 Kelvin and is therefore not possible. ");
        } else {
            System.out.println("This is also a temperature of " + tk + " kelvin. ");
        }
    }
}
